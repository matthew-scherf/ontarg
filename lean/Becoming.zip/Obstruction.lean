/-!
# Obstruction

-/

namespace Obstruction

/- ---------- worlds---------- -/

structure World : Type 1 where
  T : Type
  h : T → Bool
  tok : Prop → T

/-- A claim is a property of worlds. -/
def Claim : Type 1 := World → Prop

def DiscriminatesDenial (w : World) (A : Claim) : Prop :=
  w.h (w.tok (¬ A w)) ≠ w.h (w.tok (A w))

def Undeniable (A : Claim) : Prop :=
  ∀ w : World, DiscriminatesDenial w A → A w

theorem occurs_undeniable :
    Undeniable (fun w => ∃ t₁ t₂ : w.T, w.h t₁ ≠ w.h t₂) := by
  intro w hd
  exact ⟨w.tok (¬ (∃ t₁ t₂ : w.T, w.h t₁ ≠ w.h t₂)),
         w.tok (∃ t₁ t₂ : w.T, w.h t₁ ≠ w.h t₂), hd⟩

/- ---------- tensed worlds ---------- -/

structure TensedWorld : Type 1 where
  w : World
  succ : w.T → w.T → Prop

/-- Still: nothing succeeds anything. -/
def Still (s : TensedWorld) : Prop := ∀ t t' : s.w.T, ¬ s.succ t t'

def Runs (s : TensedWorld) : Prop :=
  ∃ seq : Nat → s.w.T,
    (∀ m n : Nat, m ≠ n → seq m ≠ seq n) ∧
    (∀ n, s.succ (seq n) (seq (n + 1))) ∧
    (∀ n, s.w.h (seq (n + 1)) = !(s.w.h (seq n)))

/- ---------- freeze lemma ---------- -/


theorem freeze (A : Claim) (w : World) (r₁ r₂ : w.T → w.T → Prop) :
    A (TensedWorld.mk w r₁).w ↔ A (TensedWorld.mk w r₂).w :=
  Iff.rfl

theorem two_models (w : World) (t : w.T) :
    (∀ A : Claim,
        A (TensedWorld.mk w (fun _ _ => False)).w
          ↔ A (TensedWorld.mk w (fun _ _ => True)).w)
    ∧ Still (TensedWorld.mk w (fun _ _ => False))
    ∧ ¬ Still (TensedWorld.mk w (fun _ _ => True)) :=
  ⟨fun _ => Iff.rfl, fun _ _ h => h, fun h => h t t trivial⟩

/- ---------- obstruction ---------- -/


theorem still_never_runs (s : TensedWorld) (hs : Still s) : ¬ Runs s :=
  fun ⟨seq, _, hsucc, _⟩ => hs (seq 0) (seq 1) (hsucc 0)


theorem obstruction {A : Claim} (hU : Undeniable A)
    (hB : ∀ s : TensedWorld, A s.w → Runs s) :
    ∀ s : TensedWorld, Still s → ¬ DiscriminatesDenial s.w A :=
  fun s hs hd => still_never_runs s hs (hB s (hU s.w hd))

theorem no_undeniable_bridge {A : Claim} (hU : Undeniable A)
    (s : TensedWorld) (hs : Still s) (hd : DiscriminatesDenial s.w A) :
    ¬ ∀ v : TensedWorld, A v.w → Runs v :=
  fun hB => obstruction hU hB s hs hd

theorem obstruction_tensed {A' : TensedWorld → Prop} {D : World → Prop}
    (hU : ∀ s : TensedWorld, D s.w → A' s)
    (hB : ∀ s : TensedWorld, A' s → Runs s) :
    ∀ s : TensedWorld, Still s → ¬ D s.w :=
  fun s hs hd => still_never_runs s hs (hB s (hU s hd))

/- ---------- premise  ---------- -/


theorem ne_eq_not : ∀ a b : Bool, a ≠ b → b = !a := by
  intro a b h
  cases a <;> cases b
  · exact absurd rfl h
  · rfl
  · rfl
  · exact absurd rfl h

def Successive (s : TensedWorld) (tok : Prop → s.w.T) (X : Prop) : Prop :=
  s.succ (tok (¬ X)) (tok X)

theorem actuality_tick (s : TensedWorld) (tok : Prop → s.w.T) (X : Prop)
    (hd : s.w.h (tok (¬ X)) ≠ s.w.h (tok X))
    (hax : Successive s tok X) :
    s.succ (tok (¬ X)) (tok X)
      ∧ s.w.h (tok X) = !(s.w.h (tok (¬ X))) :=
  ⟨hax, ne_eq_not _ _ hd⟩

theorem chain_runs (s : TensedWorld) (seq : Nat → s.w.T)
    (hinj : ∀ m n : Nat, m ≠ n → seq m ≠ seq n)
    (hsucc : ∀ n, s.succ (seq n) (seq (n + 1)))
    (hd : ∀ n, s.w.h (seq n) ≠ s.w.h (seq (n + 1))) : Runs s :=
  ⟨seq, hinj, hsucc, fun n => ne_eq_not _ _ (hd n)⟩

/- ---------- independence of the premise ---------- -/

def stillWitness : TensedWorld :=
  ⟨⟨Bool, id, fun _ => true⟩, fun _ _ => False⟩


def runningWitness : TensedWorld :=
  ⟨⟨Bool, id, fun _ => true⟩, fun _ _ => True⟩


theorem premise_underivable :
    (∃ t₁ t₂ : stillWitness.w.T, stillWitness.w.h t₁ ≠ stillWitness.w.h t₂)
    ∧ Still stillWitness
    ∧ ∀ (tok : Prop → stillWitness.w.T) (X : Prop),
        stillWitness.w.h (tok (¬ X)) ≠ stillWitness.w.h (tok X) →
          tok (¬ X) ≠ tok X
          ∧ stillWitness.w.h (tok X) = !(stillWitness.w.h (tok (¬ X)))
          ∧ ¬ Successive stillWitness tok X := by
  refine ⟨⟨true, false, by decide⟩, fun _ _ h => h, ?_⟩
  intro tok X hd
  exact ⟨fun he => hd (congrArg stillWitness.w.h he),
         ne_eq_not _ _ hd,
         fun h => h⟩

theorem premise_unrefutable :
    ∀ (tok : Prop → runningWitness.w.T) (X : Prop),
      Successive runningWitness tok X :=
  fun _ _ => trivial

theorem premise_independent :
    (∀ (tok : Prop → stillWitness.w.T) (X : Prop),
        ¬ Successive stillWitness tok X)
    ∧ (∀ (tok : Prop → runningWitness.w.T) (X : Prop),
        Successive runningWitness tok X) :=
  ⟨fun _ _ h => h, fun _ _ => trivial⟩

theorem chain_premise_independent :
    (∀ seq : Nat → stillWitness.w.T,
        ¬ ∀ n, stillWitness.succ (seq n) (seq (n + 1)))
    ∧ (∀ seq : Nat → runningWitness.w.T,
        ∀ n, runningWitness.succ (seq n) (seq (n + 1))) :=
  ⟨fun _ h => h 0, fun _ _ => trivial⟩

theorem self_ne_not : ∀ b : Bool, b ≠ !b := by
  intro b; cases b <;> decide

def alt : Nat → Bool
  | 0 => true
  | n + 1 => !(alt n)

def chainWitness : TensedWorld :=
  ⟨⟨Nat, alt, fun _ => 0⟩, fun _ _ => True⟩

theorem chain_hypothesis_realizable :
    ∃ seq : Nat → chainWitness.w.T,
      (∀ m n : Nat, m ≠ n → seq m ≠ seq n)
      ∧ (∀ n, chainWitness.succ (seq n) (seq (n + 1)))
      ∧ (∀ n, chainWitness.w.h (seq n) ≠ chainWitness.w.h (seq (n + 1))) :=
  ⟨fun n => n, fun _ _ h => h, fun _ => trivial,
   fun n => self_ne_not (alt n)⟩

/- ---------- rigidity ---------- -/

theorem no_half_tick : ∀ a u b : Bool, b = !a → u = !a → b = !u → False := by
  decide

theorem no_interpolation (s : TensedWorld) (seq : Nat → s.w.T)
    (hrun : ∀ n, s.w.h (seq (n + 1)) = !(s.w.h (seq n))) (n : Nat) (u : s.w.T)
    (before : s.w.h u = !(s.w.h (seq n)))
    (after : s.w.h (seq (n + 1)) = !(s.w.h u)) : False :=
  no_half_tick (s.w.h (seq n)) (s.w.h u) (s.w.h (seq (n + 1)))
    (hrun n) before after

theorem prior_value_exists : ∀ x : Bool, ∃ p : Bool, x = !p := by
  decide

theorem prior_token_determined (s : TensedWorld) (t₀ p q : s.w.T)
    (hp : s.w.h t₀ = !(s.w.h p)) (hq : s.w.h t₀ = !(s.w.h q)) :
    s.w.h p = s.w.h q := by
  revert hp hq
  cases s.w.h t₀ <;> cases s.w.h p <;> cases s.w.h q <;> decide

end Obstruction

/- audit -/
#print axioms Obstruction.occurs_undeniable
#print axioms Obstruction.freeze
#print axioms Obstruction.two_models
#print axioms Obstruction.still_never_runs
#print axioms Obstruction.obstruction
#print axioms Obstruction.no_undeniable_bridge
#print axioms Obstruction.obstruction_tensed
#print axioms Obstruction.actuality_tick
#print axioms Obstruction.chain_runs
#print axioms Obstruction.premise_underivable
#print axioms Obstruction.premise_unrefutable
#print axioms Obstruction.premise_independent
#print axioms Obstruction.chain_premise_independent
#print axioms Obstruction.chain_hypothesis_realizable
#print axioms Obstruction.no_interpolation
#print axioms Obstruction.prior_value_exists
#print axioms Obstruction.prior_token_determined
